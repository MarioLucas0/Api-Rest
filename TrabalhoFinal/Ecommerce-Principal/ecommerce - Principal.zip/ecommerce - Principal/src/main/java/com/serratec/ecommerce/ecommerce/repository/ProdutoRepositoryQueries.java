package com.serratec.ecommerce.ecommerce.repository;

public class ProdutoRepositoryQueries {

}