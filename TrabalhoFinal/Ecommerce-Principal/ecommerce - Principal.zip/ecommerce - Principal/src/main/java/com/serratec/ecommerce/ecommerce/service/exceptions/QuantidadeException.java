package com.serratec.ecommerce.ecommerce.service.exceptions;

public class QuantidadeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public QuantidadeException(String message) {
    super(message);
  }
}
