package com.serratec.ecommerce.ecommerce.service.exceptions;

public class FindIdException extends RuntimeException {

    public FindIdException(String message) {
        super(message);
    }
}
