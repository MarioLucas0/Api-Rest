package com.serratec.ecommerce.ecommerce.model;

public enum Status {

  ORDER_SENT,
  DELIVERED

}