package com.serratec.ecommerce.ecommerce.service.exceptions;

public class PedidoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public PedidoException(String message) {
        super(message);
    }

}
